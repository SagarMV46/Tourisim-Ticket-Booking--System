const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("./db");

const app = express();

app.use(cors());
app.use(express.json());

const JWT_SECRET = "tourism_secret_key";

function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ message: "No token provided" });
  }

  const token = authHeader.split(" ")[1];

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ message: "Invalid token" });
    }

    req.user = decoded;
    next();
  });
}

app.post("/api/register", async (req, res) => {
  const { name, email, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";

  db.query(sql, [name, email, hashedPassword], (err) => {
    if (err) {
      return res.status(400).json({ message: "Email already exists" });
    }

    res.json({ message: "User registered successfully" });
  });
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  const sql = "SELECT * FROM users WHERE email = ?";

  db.query(sql, [email], async (err, results) => {
    if (err || results.length === 0) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const token = jwt.sign(
      { id: user.id, name: user.name, role: user.role },
      JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user.id,
        name: user.name,
        role: user.role
      }
    });
  });
});

app.get("/api/tours", (req, res) => {
  const sql = "SELECT * FROM tours ORDER BY rating DESC";

  db.query(sql, (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Failed to fetch tours" });
    }

    res.json(results);
  });
});

app.get("/api/tours/search", (req, res) => {
  const { keyword } = req.query;

  const sql = `
    SELECT * FROM tours 
    WHERE title LIKE ? OR location LIKE ? OR description LIKE ?
  `;

  const value = `%${keyword}%`;

  db.query(sql, [value, value, value], (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Search failed" });
    }

    res.json(results);
  });
});

app.post("/api/bookings", verifyToken, (req, res) => {
  const { tour_id, travelers, booking_date, total_amount } = req.body;

  const sql = `
    INSERT INTO bookings 
    (user_id, tour_id, travelers, booking_date, total_amount, payment_status)
    VALUES (?, ?, ?, ?, ?, 'paid')
  `;

  db.query(
    sql,
    [req.user.id, tour_id, travelers, booking_date, total_amount],
    (err) => {
      if (err) {
        return res.status(500).json({ message: "Booking failed" });
      }

      db.query(
        "UPDATE tours SET available_seats = available_seats - ? WHERE id = ?",
        [travelers, tour_id]
      );

      res.json({ message: "Booking confirmed successfully" });
    }
  );
});

app.get("/api/my-bookings", verifyToken, (req, res) => {
  const sql = `
    SELECT 
      bookings.*, 
      tours.title, 
      tours.location, 
      tours.image_url 
    FROM bookings
    JOIN tours ON bookings.tour_id = tours.id
    WHERE bookings.user_id = ?
    ORDER BY bookings.created_at DESC
  `;

  db.query(sql, [req.user.id], (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Failed to fetch bookings" });
    }

    res.json(results);
  });
});

app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});