CREATE DATABASE tourism_booking;
USE tourism_booking;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    location VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    duration VARCHAR(50),
    image_url TEXT,
    available_seats INT DEFAULT 50,
    rating DECIMAL(2,1) DEFAULT 4.5
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    tour_id INT,
    travelers INT NOT NULL,
    booking_date DATE NOT NULL,
    total_amount DECIMAL(10,2),
    payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    booking_status ENUM('confirmed', 'cancelled') DEFAULT 'confirmed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (tour_id) REFERENCES tours(id)
);

INSERT INTO tours 
(title, location, description, price, duration, image_url, available_seats, rating)
VALUES
('Goa Beach Escape', 'Goa', 'Enjoy beaches, nightlife, water sports and luxury resorts.', 7999, '4 Days / 3 Nights', 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2', 40, 4.8),
('Manali Adventure Trip', 'Himachal Pradesh', 'Snow mountains, paragliding, trekking and scenic valleys.', 9999, '5 Days / 4 Nights', 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee', 35, 4.7),
('Jaipur Heritage Tour', 'Rajasthan', 'Explore palaces, forts, royal food and colorful bazaars.', 6999, '3 Days / 2 Nights', 'https://images.unsplash.com/photo-1599661046289-e31897846e41', 45, 4.6),
('Kerala Backwater Cruise', 'Kerala', 'Houseboats, backwaters, Ayurveda and peaceful nature.', 11999, '5 Days / 4 Nights', 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944', 25, 4.9);