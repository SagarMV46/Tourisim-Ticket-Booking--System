const API_URL = "http://localhost:5000/api";

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("tourContainer")) {
    loadTours();
  }

  if (document.getElementById("bookingContainer")) {
    loadBookings();
  }
});

async function loadTours() {
  const response = await fetch(`${API_URL}/tours`);
  const tours = await response.json();
  displayTours(tours);
}

function displayTours(tours) {
  const container = document.getElementById("tourContainer");
  container.innerHTML = "";

  tours.forEach((tour) => {
    const card = document.createElement("div");
    card.className = "tour-card";

    card.innerHTML = `
      <img src="${tour.image_url}" alt="${tour.title}">
      <div class="tour-info">
        <h3>${tour.title}</h3>
        <p>${tour.description}</p>
        <div class="meta">
          <span>${tour.location}</span>
          <span>${tour.rating} ★</span>
        </div>
        <div class="meta">
          <span>${tour.duration}</span>
          <span>${tour.available_seats} seats</span>
        </div>
        <div class="price">₹${Number(tour.price).toLocaleString()}</div>
        <button class="book-btn" onclick="bookTour(${tour.id}, ${tour.price})">
          Book Now
        </button>
      </div>
    `;

    container.appendChild(card);
  });
}

async function searchTours() {
  const keyword = document.getElementById("searchInput").value;

  if (!keyword.trim()) {
    loadTours();
    return;
  }

  const response = await fetch(`${API_URL}/tours/search?keyword=${keyword}`);
  const tours = await response.json();

  displayTours(tours);
}

async function registerUser() {
  const name = document.getElementById("registerName").value;
  const email = document.getElementById("registerEmail").value;
  const password = document.getElementById("registerPassword").value;

  const response = await fetch(`${API_URL}/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ name, email, password })
  });

  const data = await response.json();
  alert(data.message);

  if (response.ok) {
    window.location.href = "login.html";
  }
}

async function loginUser() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const response = await fetch(`${API_URL}/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ email, password })
  });

  const data = await response.json();
  alert(data.message);

  if (response.ok) {
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));
    window.location.href = "index.html";
  }
}

async function bookTour(tourId, price) {
  const token = localStorage.getItem("token");

  if (!token) {
    alert("Please login before booking.");
    window.location.href = "login.html";
    return;
  }

  const travelers = prompt("Enter number of travelers:");

  if (!travelers || travelers <= 0) {
    alert("Invalid traveler count");
    return;
  }

  const bookingDate = prompt("Enter travel date in YYYY-MM-DD format:");

  if (!bookingDate) {
    alert("Travel date is required");
    return;
  }

  const totalAmount = Number(price) * Number(travelers);

  const confirmBooking = confirm(
    `Total amount: ₹${totalAmount.toLocaleString()}\nConfirm booking?`
  );

  if (!confirmBooking) return;

  const response = await fetch(`${API_URL}/bookings`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({
      tour_id: tourId,
      travelers,
      booking_date: bookingDate,
      total_amount: totalAmount
    })
  });

  const data = await response.json();
  alert(data.message);

  if (response.ok) {
    loadTours();
  }
}

async function loadBookings() {
  const token = localStorage.getItem("token");

  if (!token) {
    alert("Please login first.");
    window.location.href = "login.html";
    return;
  }

  const response = await fetch(`${API_URL}/my-bookings`, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  const bookings = await response.json();
  const container = document.getElementById("bookingContainer");

  container.innerHTML = "";

  bookings.forEach((booking) => {
    const card = document.createElement("div");
    card.className = "booking-card";

    card.innerHTML = `
      <img src="${booking.image_url}" alt="${booking.title}">
      <div>
        <h3>${booking.title}</h3>
        <p><strong>Location:</strong> ${booking.location}</p>
        <p><strong>Travelers:</strong> ${booking.travelers}</p>
        <p><strong>Date:</strong> ${booking.booking_date}</p>
        <p><strong>Total:</strong> ₹${Number(booking.total_amount).toLocaleString()}</p>
        <span class="status">${booking.payment_status}</span>
      </div>
    `;

    container.appendChild(card);
  });
}

function logoutUser() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
}